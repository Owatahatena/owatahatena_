from .owatahatena import owatahatena
